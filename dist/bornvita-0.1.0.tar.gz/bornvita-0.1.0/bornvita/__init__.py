from .brainrot import generate_brainrot
